﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VVVInternalTemplate.Mods
{
    internal class Fun
    {
        public static void GhostMonke1()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
    }
}
 

