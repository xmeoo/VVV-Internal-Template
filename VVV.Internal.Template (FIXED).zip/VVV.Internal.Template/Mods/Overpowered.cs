﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace VVVInternalTemplate.Mods
{
    internal class Overpowered
    {
        public static void copyclosest()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
                bool flag2 = flag;
                if (flag2)
                {
                    int num = 4;
                    Vector3 position = vrrig.transform.position;
                    Vector3 position2 = GorillaTagger.Instance.bodyCollider.transform.position;
                    float num2 = Vector3.Distance(position, position2);
                    bool flag3 = num2 <= (float)num;
                    bool flag4 = flag3;
                    if (flag4)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position;
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = vrrig.transform.rotation;
                        GorillaTagger.Instance.offlineVRRig.head.rigTarget.position = vrrig.head.rigTarget.position;
                        GorillaTagger.Instance.offlineVRRig.head.rigTarget.rotation = vrrig.head.rigTarget.rotation;
                        GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.position = vrrig.leftHand.rigTarget.position;
                        GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.rotation = vrrig.leftHand.rigTarget.rotation;
                        GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.position = vrrig.rightHand.rigTarget.position;
                        GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.rotation = vrrig.rightHand.rigTarget.rotation;
                    }
                    else
                    {
                        Overpowered.enablerig();
                    }
                }
            }
        }
        public static void enablerig()
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }
}