﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace VVVInternalTemplate.Mods
{
    internal class Visual
    {
        public static void Chams()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
                bool flag2 = flag;
                if (flag2)
                {
                    bool flag3 = vrrig.mainSkin.material.name.Contains("fected");
                    bool flag4 = flag3;
                    if (flag4)
                    {
                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                        vrrig.mainSkin.material.color = new Color32(byte.MaxValue, 0, 0, byte.MaxValue);
                    }
                    else
                    {
                        vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                        vrrig.mainSkin.material.color = new Color32(0, byte.MaxValue, 0, byte.MaxValue);
                    }
                }
            }
        }

        // Token: 0x06000084 RID: 132 RVA: 0x0000B624 File Offset: 0x00009824
        public static void ChamsOff()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
                bool flag2 = flag;
                if (flag2)
                {
                    vrrig.mainSkin.material.shader = Shader.Find("GorillaTag/UberShader");
                    vrrig.mainSkin.material.color = vrrig.playerColor;
                }
            }
        }

    }
}
