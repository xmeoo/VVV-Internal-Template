﻿using StupidTemplate.Classes;
using StupidTemplate.Mods;
using VVVInternalTemplate.Mods;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Opens the main settings page for the menu."},
                new ButtonInfo { buttonText = "Advantage Mods", method =() => SettingsMods.Advantage(), isTogglable = false, toolTip = "Opens the advantage mods page for the menu."},
                new ButtonInfo { buttonText = "Fun Mods", method =() => SettingsMods.Fun(), isTogglable = false, toolTip = "Opens the fun mods page for the menu."},
                new ButtonInfo { buttonText = "Movemnet Mods", method =() => SettingsMods.Movement(), isTogglable = false, toolTip = "Opens the movemnet mods page for the menu."},
                new ButtonInfo { buttonText = "Overpowered Mods", method =() => SettingsMods.Overpowered(), isTogglable = false, toolTip = "Opens the overpowered mods page for the menu."},
                new ButtonInfo { buttonText = "Projectile Mods", method =() => SettingsMods.Projectile(), isTogglable = false, toolTip = "Opens the projectile mods page for the menu."},
                new ButtonInfo { buttonText = "Room Mods", method =() => SettingsMods.Room(), isTogglable = false, toolTip = "Opens the main room mods for the menu."},
                new ButtonInfo { buttonText = "Safety Mods", method =() => SettingsMods.Safety(), isTogglable = false, toolTip = "Opens the safety mods page for the menu."},
                new ButtonInfo { buttonText = "Visual Mods", method =() => SettingsMods.Visual(), isTogglable = false, toolTip = "Opens the visual mods page for the menu."},
            },

            new ButtonInfo[] { // Settings
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "Menu", method =() => SettingsMods.MenuSettings(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Movement", method =() => SettingsMods.MovementSettings(), isTogglable = false, toolTip = "Opens the movement settings for the menu."},
                new ButtonInfo { buttonText = "Projectile", method =() => SettingsMods.ProjectileSettings(), isTogglable = false, toolTip = "Opens the projectile settings for the menu."},
            },

            new ButtonInfo[] { // Menu Settings
                new ButtonInfo { buttonText = "Return to Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Returns to the main settings page for the menu."},
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
            },

            new ButtonInfo[] { // Movement Settings
                new ButtonInfo { buttonText = "Return to Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Returns to the main settings page for the menu."},
            },

            new ButtonInfo[] { // Projectile Settings
                new ButtonInfo { buttonText = "Return to Settings", method =() => SettingsMods.MenuSettings(), isTogglable = false, toolTip = "Opens the settings for the menu."},
            },

            new ButtonInfo[] { // Advantage
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Speedboost", method =() => Advantage.Speedboost(), isTogglable = true, toolTip = "Gives you a speed boost."},
            },

            new ButtonInfo[] { // Fun
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Ghost Monke", method =() => Fun.GhostMonke1(), isTogglable = false, toolTip = "Pauses your rig for everyone else."},
            },

            new ButtonInfo[] { // Movement
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Platforms", method =() => Movement.platforms(), isTogglable = true, toolTip = "Platforms."},
            },

            new ButtonInfo[] { // Overpowered
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Copy Closest", method =() => Overpowered.copyclosest(), isTogglable = false, toolTip = "Copies the closest player."},
            },

            new ButtonInfo[] { // Projectile
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Throw Up", method =() => Projectiles.Throw(), isTogglable = false, toolTip = "Throw up..."},
            },

            new ButtonInfo[] { // Room
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Disconnect (A)", method =() => Room.PrimaryDisconnect(), isTogglable = true, toolTip = "Disconnect with A."},
                new ButtonInfo { buttonText = "Disconnect (X)", method =() => Room.PrimaryDisconnect2(), isTogglable = true, toolTip = "Disconnect with X."},
            },

            new ButtonInfo[] { // Safety
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Anti Report", method =() => Safety.AntiReport(), isTogglable = true, toolTip = "Disconnects you when someone tries to report you."},
            },

            new ButtonInfo[] { // Visual
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Chams", method =() => Visual.Chams(), isTogglable = true, toolTip = "Chams."},
                new ButtonInfo { buttonText = "Disable Chams", method =() => Visual.ChamsOff(), isTogglable = true, toolTip = "No chams."},
            },
        };
    }
}
