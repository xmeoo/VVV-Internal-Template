﻿using GorillaLocomotion;
using System;
using System.Collections.Generic;
using System.Text;

namespace VVVInternalTemplate.Mods
{
    internal class Advantage
    {

        public static void Speedboost()
        {
            GTPlayer.Instance.maxJumpSpeed = 8f;
            GTPlayer.Instance.jumpMultiplier = 2f;
        }
    }
}
