﻿using GorillaLocomotion;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace VVVInternalTemplate.Mods
{
    internal class Movement
    {
        public static void platforms()
        {
            bool leftGrab = ControllerInputPoller.instance.leftGrab;
            bool flag = leftGrab;
            if (flag)
            {
                bool flag2 = Movement.platL == null;
                bool flag3 = flag2;
                if (flag3)
                {
                    Movement.platL = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    Movement.platL.transform.localScale = new Vector3(0.04f, 0.28f, 0.353f);
                    Movement.platL.transform.position = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.06f, 0f);
                    Movement.platL.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                    Movement.platL.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    Movement.platL.GetComponent<Renderer>().material.color = Main.menuColor;
                    ColorChanger colorChanger = Movement.platL.AddComponent<ColorChanger>();
                    colorChanger.Start();
                }
            }
            else
            {
                bool flag4 = Movement.platL != null;
                bool flag5 = flag4;
                if (flag5)
                {
                    Rigidbody rigidbody = Movement.platL.AddComponent(typeof(Rigidbody)) as Rigidbody;
                    rigidbody.velocity = GTPlayer.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
                    UnityEngine.Object.Destroy(Movement.platL, 2f);
                    Movement.platL = null;
                }
            }
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            bool flag6 = rightGrab;
            if (flag6)
            {
                bool flag7 = Movement.platR == null;
                bool flag8 = flag7;
                if (flag8)
                {
                    Movement.platR = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    Movement.platR.transform.localScale = new Vector3(0.04f, 0.28f, 0.353f);
                    Movement.platR.transform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.06f, 0f);
                    Movement.platR.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                    Movement.platR.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    Movement.platR.GetComponent<Renderer>().material.color = Main.menuColor;
                    ColorChanger colorChanger2 = Movement.platR.AddComponent<ColorChanger>();
                    colorChanger2.Start();
                }
            }
            else
            {
                bool flag9 = Movement.platR != null;
                bool flag10 = flag9;
                if (flag10)
                {
                    Rigidbody rigidbody2 = Movement.platR.AddComponent(typeof(Rigidbody)) as Rigidbody;
                    rigidbody2.velocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
                    UnityEngine.Object.Destroy(Movement.platR, 2f);
                    Movement.platR = null;
                }
            }
        }

       
        private static GameObject platL;

      
        private static GameObject platR;
    }
}