﻿using GorillaLocomotion;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;

namespace VVVInternalTemplate.Mods
{
    internal class Projectiles
    {
        public static float f { get; private set; }

        public static void Throw()
        {
            bool flag = Projectiles.f < Time.time;
            bool flag2 = flag;
            if (flag2)
            {
                Projectiles.f = Time.time + 0.05f;
                bool flag3 = ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed;
                bool flag4 = flag3;
                if (flag4)
                {
                    GameObject gameObject = ObjectPools.instance.Instantiate(-675036877, true);
                    SlingshotProjectile component = gameObject.GetComponent<SlingshotProjectile>();
                    int num = 0;
                    component.Launch(GorillaTagger.Instance.headCollider.transform.position + GorillaTagger.Instance.headCollider.transform.forward * 0.1f + GorillaTagger.Instance.headCollider.transform.up * -0.15f, GorillaTagger.Instance.bodyCollider.transform.forward * 10f, NetworkSystem.Instance.LocalPlayer, false, false, num++, 1f, true, Color.green);
                }
            }
        }

    }
}
