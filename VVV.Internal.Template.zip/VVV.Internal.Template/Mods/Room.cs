﻿using System;
using System.Collections.Generic;
using System.Text;
using Photon.Pun;

namespace VVVInternalTemplate.Mods
{
    internal class Room
    {
        public static void PrimaryDisconnect()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                PhotonNetwork.Disconnect();
            }
        }
        public static void PrimaryDisconnect2()
        {
            if (ControllerInputPoller.instance.leftControllerPrimaryButton)
            {
                PhotonNetwork.Disconnect();
            }
        }
    }
}
