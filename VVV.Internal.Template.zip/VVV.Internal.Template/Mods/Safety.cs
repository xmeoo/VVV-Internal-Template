﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace VVVInternalTemplate.Mods
{
    internal class Safety
    {
        public static void AntiReport()
        {
            foreach (GorillaPlayerScoreboardLine line in UnityEngine.Object.FindObjectsOfType<GorillaPlayerScoreboardLine>())
            {
                if (line.linePlayer.UserId == PhotonNetwork.LocalPlayer.UserId)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (Vector3.Distance(vrrig.leftHandTransform.position, line.reportButton.transform.position) < 0.3f)
                        {
                            PhotonNetwork.Disconnect();
                            PhotonNetwork.ConnectUsingSettings();
                        }
                        if (Vector3.Distance(vrrig.rightHandTransform.position, line.reportButton.transform.position) < 0.3f)
                        {
                            PhotonNetwork.Disconnect();
                            PhotonNetwork.ConnectUsingSettings();
                        }
                    }
                }
            }
        }
    }
}
